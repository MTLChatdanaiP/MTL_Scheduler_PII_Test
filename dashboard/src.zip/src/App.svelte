<script lang="ts">

    import Overview from "./routes/Overview.svelte";

    const pages = [
        "Overview",
        "Runs",
        "Queues",
        "Workers",
        "Schedules",
        "Alerts",
        "PII Findings",
        "Monitoring Health",
        "Components"
    ];

    let activePage = "Overview";
</script>

<div class="dashboard">
    <aside class="sidebar">
        <h1>MTL Scheduler</h1>

        <nav>
            {#each pages as page}
                <button
                    class:active={activePage === page}
                    onclick={() => activePage = page}
                >
                    {page}
                </button>
            {/each}
        </nav>
    </aside>

    <main>
        <header>
            <h2>{activePage}</h2>
        </header>

        <section class="content">
          {#if activePage === "Overview"}
              <Overview/>
          {:else}
              <p>Current page: {activePage}</p>
          {/if}
      </section>
    </main>
</div>

<style>
    .dashboard {
        display: flex;
        min-height: 100vh;
    }

    .sidebar {
        width: 220px;
        padding: 20px;
        border-right: 1px solid #ddd;
    }

    .sidebar h1 {
        font-size: 20px;
        margin-bottom: 30px;
    }

    nav {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    nav button {
        padding: 10px;
        text-align: left;
        background: none;
        border: none;
        cursor: pointer;
    }

    nav button.active {
        font-weight: bold;
        background: #eee;
    }

    main {
        flex: 1;
    }

    header {
        padding: 20px;
        border-bottom: 1px solid #ddd;
    }

    header h2 {
        margin-top: 0;
    }

    .controls {
        display: flex;
        gap: 20px;
        align-items: center;
    }

    .content {
        padding: 20px;
    }
</style>