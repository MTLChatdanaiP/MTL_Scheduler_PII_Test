import { writable } from "svelte/store";

export type TimeRange = "15m" | "1h" | "6h" | "24h" | "7d" | "custom";

export const timeRange = writable<TimeRange>("1h");
export const autoRefreshEnabled = writable<boolean>(true);
export const lastRefreshedAt = writable<Date | null>(null);
export const globalSearchQuery = writable<string>("");