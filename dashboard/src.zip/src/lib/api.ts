const BASE_URL = "http://localhost:8080";
const API_KEY = "dev-local-key-changeme";

export interface Alert {
    alert_id: string;
    alert_type: string;
    severity: string;
    status: string;
    opened_at: string;
    resolved_at: string | null;
    subject_type: string;
    subject_id: string;
    rule_id: string;
    rule_version: number;
    evidence: string;
    summary: string;
}

export interface AlertsResponse {
    alerts: Alert[];
}

async function apiFetch<T>(path: string): Promise<T> {
    const res = await fetch(BASE_URL + path, {
        headers: { "X-API-Key": API_KEY },
    });

    if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `request failed: ${res.status}`);
    }

    return res.json();
}

export function getAlerts(params: string = ""): Promise<AlertsResponse> {
    return apiFetch(`/alerts${params}`);
}