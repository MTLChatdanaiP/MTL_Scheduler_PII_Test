package handlers

import (
	"MTL_Scheduler_PII_Test/internals/database"
	"MTL_Scheduler_PII_Test/internals/models"
	"errors"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func GetQueues(c *gin.Context) {
	var queues []models.QueueHealth

	if err := database.DB.WithContext(c.Request.Context()).Order("sampled_at DESC").Find(&queues).Error; err != nil {
		fmt.Println("[Database] Failed to fetch queue health:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch queue health"})
		return
	}

	latest := make(map[string]models.QueueHealth)

	for _, queue := range queues {
		if _, exists := latest[queue.QueueName]; !exists {
			latest[queue.QueueName] = queue
		}
	}

	result := make([]models.QueueHealth, 0, len(latest))

	for _, queue := range latest {
		result = append(result, queue)
	}

	c.JSON(http.StatusOK, gin.H{
		"queues": result,
	})
}

func GetQueue(c *gin.Context) {
	queueName := c.Param("queue_name")

	var latest models.QueueHealth

	if err := database.DB.WithContext(c.Request.Context()).Where("queue_name = ?", queueName).Order("sampled_at DESC").First(&latest).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			c.JSON(http.StatusNotFound, gin.H{"error": "queue not found"})
			return
		}

		fmt.Println("[Database] Failed to fetch queue health:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch queue health"})
		return
	}

	var history []models.QueueHealth

	if err := database.DB.WithContext(c.Request.Context()).Where("queue_name = ?", queueName).Order("sampled_at DESC").Limit(100).Find(&history).Error; err != nil {
		fmt.Println("[Database] Failed to fetch queue history:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch queue history"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"current": latest,
		"history": history,
	})
}

func GetWorkerDetail(c *gin.Context) {
	workerID := c.Param("worker_id")

	var worker models.Worker
	if err := database.DB.WithContext(c.Request.Context()).Where("worker_id = ?", workerID).First(&worker).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			c.JSON(http.StatusNotFound, gin.H{"error": "worker not found"})
			return
		}

		fmt.Println("[Database] Failed to fetch worker:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch worker"})
		return
	}

	var latestHeartbeat models.WorkerHeartbeat
	if err := database.DB.WithContext(c.Request.Context()).Where("worker_id = ?", workerID).Order("occurred_at DESC").First(&latestHeartbeat).Error; err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			fmt.Println("[Database] Failed to fetch worker heartbeat:", err)
			c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch worker heartbeat"})
			return
		}
	}

	var attempts []models.Attempt
	if err := database.DB.WithContext(c.Request.Context()).Where("worker_id = ?", workerID).Order("started_at DESC").Find(&attempts).Error; err != nil {
		fmt.Println("[Database] Failed to fetch worker attempts:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch worker attempts"})
		return
	}

	var alerts []models.Alert
	if err := database.DB.WithContext(c.Request.Context()).Where("subject_type = ? AND subject_id = ?", "WORKER", workerID).Find(&alerts).Error; err != nil {
		fmt.Println("[Database] Failed to fetch worker alerts:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch worker alerts"})
		return
	}

	activeAttempts := make([]models.Attempt, 0)
	recentCompletions := make([]models.Attempt, 0)
	recentFailures := make([]models.Attempt, 0)

	for _, attempt := range attempts {
		if attempt.Status == "Claimed" || attempt.Status == "Started" {
			activeAttempts = append(activeAttempts, attempt)
		}

		if attempt.Status == "Succeeded" {
			recentCompletions = append(recentCompletions, attempt)
		}

		if attempt.Status == "Failed" || attempt.Status == "Abandoned" {
			recentFailures = append(recentFailures, attempt)
		}
	}

	activeAlertCount := 0
	for _, alert := range alerts {
		if alert.Status == "OPEN" {
			activeAlertCount++
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"worker_id":           worker.WorkerId,
		"instance_id":         worker.InstanceId,
		"hostname":            worker.Hostname,
		"started_at":          worker.StartedAt,
		"configured_capacity": worker.ConfiguredCapacity,
		"heartbeat":           latestHeartbeat,
		"running_attempts":    latestHeartbeat.RunningAttempts,
		"capacity":            latestHeartbeat.Capacity,
		"active_attempts":     activeAttempts,
		"recent_completions":  recentCompletions,
		"recent_failures":     recentFailures,
		"alerts":              alerts,
		"active_alert_count":  activeAlertCount,
	})
}

func GetRunTimeline(c *gin.Context) {
	runID := c.Param("run_id")

	var task models.Task
	if err := database.DB.WithContext(c.Request.Context()).Where("job_id = ?", runID).First(&task).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			c.JSON(http.StatusNotFound, gin.H{"error": "run not found"})
			return
		}

		fmt.Println("[Database] Failed to fetch run:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch run"})
		return
	}

	var events []models.EventEnvelope

	if err := database.DB.WithContext(c.Request.Context()).Where("job_id = ?", runID).Order("occurred_at ASC").Find(&events).Error; err != nil {
		fmt.Println("[Database] Failed to fetch run timeline:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch run timeline"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"run_id": runID,
		"events": events,
	})
}
